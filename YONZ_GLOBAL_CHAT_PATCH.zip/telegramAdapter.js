// ─────────────────────────────────────────────────────────────────────────
// telegramAdapter.js
//
// Adapter yang bikin Telegraf "menyamar" jadi API lama (client.sendMessage,
// client.sendFile, client.editMessage, dst — gaya GramJS) supaya index.js
// TIDAK perlu dibongkar total. Semua logic bisnis di index.js tetap sama;
// hanya lapisan pengiriman/penerimaan pesannya yang sekarang jalan di atas
// Telegraf (Bot API) untuk TEKS/MENU/TOMBOL. Untuk FILE (kirim & terima),
// SELALU lewat GramJS/MTProto (hybridFile.js + mtproto.js) — gak ada
// pengecualian ukuran, biar satu jalur aja & gak bikin bingung.
// ─────────────────────────────────────────────────────────────────────────

const { Telegraf } = require("telegraf");
const fs = require("fs");
const path = require("path");
const CONFIG = require("./config");
const hybridFile = require("./hybridFile");
const mtproto = require("./mtproto");
const { emojify, stripCustomEmoji, isEmojiError } = require("./emojify");
const richui = require("./richui");

// Semua MENU (pesan HTML yang punya tombol) dikirim sebagai pesan Rich supaya tampil
// rapi & responsif. Set RICH_MENUS=0 di env untuk mematikan (kembali ke teks biasa).
const RICH_MENUS = process.env.RICH_MENUS !== "0";

const bot = new Telegraf(CONFIG.BOT_TOKEN, { handlerTimeout: 15 * 60 * 1000 });

// YONZ Global Chat — Mini App. URL hanya berasal dari environment Render.
const GLOBAL_CHAT_URL = String(process.env.GLOBAL_CHAT_URL || "").trim();
if (GLOBAL_CHAT_URL) {
  let parsedGlobalChatUrl;
  try { parsedGlobalChatUrl = new URL(GLOBAL_CHAT_URL); } catch (_) {}
  if (parsedGlobalChatUrl?.protocol === "https:") {
    bot.command("globalchat", async (ctx) => {
      await ctx.reply("🌐 <b>YONZ GLOBAL CHAT</b>\n\nChat global realtime. Tekan tombol di bawah untuk masuk melalui Telegram Mini App.", {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "OPEN GLOBAL CHAT", web_app: { url: GLOBAL_CHAT_URL } }]] },
      });
    });
  } else {
    console.warn("[global-chat] GLOBAL_CHAT_URL harus berupa URL HTTPS yang valid.");
  }
}

// Sambutan native Rich Message ketika anggota baru benar-benar masuk ke grup.
// Menggunakan foto menu yang dikonfigurasi dan tombol rich yang sama dengan menu bot.
const welcomedJoinKeys = new Set();
bot.on("new_chat_members", async (ctx) => {
  const chat = ctx.message?.chat;
  const members = ctx.message?.new_chat_members || [];
  if (!chat || !Array.isArray(members) || !members.length || chat.type === "private") return;
  try {
    const me = await ctx.telegram.getMe();
    const botUrl = me?.username ? `https://t.me/${me.username}` : "https://t.me";
    const groupUrl = me?.username ? `https://t.me/${me.username}?startgroup=true` : null;
    let memberCount = null;
    try { memberCount = await ctx.telegram.getChatMemberCount(chat.id); } catch (_) {}
    for (const member of members) {
      if (!member || String(member.id) === String(me?.id)) continue;
      const key = `${chat.id}:${ctx.message.message_id}:${member.id}`;
      if (welcomedJoinKeys.has(key)) continue;
      welcomedJoinKeys.add(key);
      if (welcomedJoinKeys.size > 1000) welcomedJoinKeys.delete(welcomedJoinKeys.values().next().value);
      const memberName = [member.first_name, member.last_name].filter(Boolean).join(" ") || member.username || "Teman baru";
      const welcome = richui.buildGroupJoinWelcome({
        memberName,
        username: member.username || "",
        chatTitle: chat.title || "Grup",
        memberCount,
        botUrl,
        groupUrl,
      });
      await richui.sendRichSafe(chat.id, welcome.html, welcome.markup);
    }
  } catch (err) {
    console.warn("[welcome] Rich join welcome gagal:", err?.response?.data?.description || err?.message || err);
  }
});

// Kelas penanda doang (buat instanceof di index.js), gak ada logic di dalamnya.
class NewMessage {
  constructor(_opts) {}
}
class CallbackQuery {
  constructor(_opts) {}
}

let messageHandler = null;
let callbackHandler = null;

// Hook mentah: modul fitur (Live Photo, Rich AI, Jaga Grup) mendaftarkan fungsi
// yang menerima SEMUA update Telegraf lebih dulu. Return true = update sudah
// ditangani (tidak diteruskan ke handler utama). Error di hook tidak pernah
// menjatuhkan bot.
const rawHooks = [];
function registerRawHook(fn) {
  if (typeof fn === "function") rawHooks.push(fn);
}

function mapParseMode(pm) {
  if (!pm) return undefined;
  const v = String(pm).toLowerCase();
  if (v === "html") return "HTML";
  if (v === "md" || v === "markdown") return "Markdown";
  return undefined;
}

function wrapOutgoing(msg) {
  if (!msg || typeof msg !== "object") return msg;
  return { ...msg, id: msg.message_id };
}

// Telegram (Bot API & MTProto) WAJIB format "@username" buat channel/grup
// by username. CONFIG.CHANNEL_USERNAME dkk di config.js disimpen TANPA "@"
// (mis. "NAMACHANNEL"), jadi kalau dikirim apa adanya ke Telegraf, chat-nya
// gak ketemu & pesan gagal terkirim DIAM-DIAM (gak selalu throw error jelas).
// ID numerik (termasuk grup/channel "-100...") dibiarin apa adanya.
function normalizeChatId(chatId) {
  if (typeof chatId !== "string") return chatId; // udah numeric id
  if (/^-?\d+$/.test(chatId)) return chatId; // "-1001234..." dst
  return chatId.startsWith("@") ? chatId : `@${chatId}`;
}

// Ubah pesan Telegraf jadi bentuk media yang dipahami index.js
// (media.document.size / .attributes[].fileName / media.isPhoto / media.photo)
// chatId+msgId disertain supaya kalau media ini nanti mau di-forward ulang
// (mis. broadcast), hybridFile bisa native-forward via MTProto tanpa download.
function extractMedia(tgMsg, chatId) {
  if (!tgMsg) return null;

  if (tgMsg.document) {
    const d = tgMsg.document;
    return {
      isPhoto: false,
      photo: null,
      fileId: d.file_id,
      size: d.file_size || 0,
      chatId,
      messageId: tgMsg.message_id,
      document: {
        size: d.file_size || 0,
        fileId: d.file_id,
        attributes: [{ fileName: d.file_name || "" }],
      },
    };
  }

  if (tgMsg.photo && tgMsg.photo.length) {
    const largest = tgMsg.photo[tgMsg.photo.length - 1];
    return {
      isPhoto: true,
      photo: { size: largest.file_size || 0 },
      document: null,
      fileId: largest.file_id,
      size: largest.file_size || 0,
      chatId,
      messageId: tgMsg.message_id,
    };
  }

  if (tgMsg.video) {
    const v = tgMsg.video;
    return {
      isPhoto: false,
      photo: null,
      fileId: v.file_id,
      size: v.file_size || 0,
      chatId,
      messageId: tgMsg.message_id,
      document: {
        size: v.file_size || 0,
        fileId: v.file_id,
        attributes: [{ fileName: v.file_name || "video.mp4" }],
      },
    };
  }

  return null;
}

function wrapMessage(tgMsg, chatId, chatType) {
  if (!tgMsg) return null;
  const media = extractMedia(tgMsg, chatId);
  return {
    id: tgMsg.message_id,
    chatId,
    senderId: tgMsg.from?.id,
    text: tgMsg.text || tgMsg.caption || "",
    entities: tgMsg.entities || tgMsg.caption_entities || [],
    media,
    document: media?.document ? { file_name: media.document.attributes[0]?.fileName || "" } : null,
    // true kalau chat privat 1-on-1, false kalau grup/channel — dipakai buat
    // ganti pengecekan lama GramJS (event.message.peerId.className !== "PeerUser")
    isPrivate: chatType ? chatType === "private" : true,
    getSender: async () => ({
      id: tgMsg.from?.id,
      username: tgMsg.from?.username,
      firstName: tgMsg.from?.first_name,
    }),
    getReplyMessage: async () => wrapMessage(tgMsg.reply_to_message, chatId, chatType),
  };
}

function addEventHandler(handler, filter) {
  if (filter instanceof CallbackQuery) callbackHandler = handler;
  else messageHandler = handler;
}

// ── API "client.*" gaya GramJS, diimplementasi pakai Telegraf (teks/menu)
//    dan GramJS murni (file, apapun ukurannya) ─────────────────────────

// Kalau `file` yang dikasih adalah object media hasil getReplyMessage()/msg.media
// (bukan path lokal), ubah jadi referensi {chatId, messageId} biar hybridFile
// bisa native-forward pesan aslinya lewat MTProto tanpa download-upload ulang.
function normalizeFileArg(file) {
  if (file && typeof file === "object" && file.fileId) {
    return { file: null, forwardRef: { chatId: file.chatId, messageId: file.messageId } };
  }
  return { file, forwardRef: null };
}

async function sendMessage(chatId, opts = {}) {
  chatId = normalizeChatId(chatId);
  const parse_mode = mapParseMode(opts.parseMode);
  const rawText = opts.message ?? opts.text ?? "";
  const text = opts.file ? rawText : emojify(rawText, { parseMode: parse_mode }); // file -> GramJS, caption sengaja tidak di-emojify
  const reply_markup = opts.buttons ? { inline_keyboard: opts.buttons } : undefined;

  if (opts.file) {
    const { file, forwardRef } = normalizeFileArg(opts.file);
    return wrapOutgoing(
      await hybridFile.sendFileSmart(bot, chatId, {
        file,
        forwardRef,
        caption: text,
        parse_mode,
        reply_markup,
        forceDocument: opts.forceDocument,
      })
    );
  }
  if (RICH_MENUS && parse_mode === "HTML" && Array.isArray(opts.buttons) && opts.buttons.length) {
    try {
      return wrapOutgoing(await richui.sendRich(chatId, richui.htmlToRich(rawText), reply_markup));
    } catch (e) {
      console.warn("[adapter] menu rich gagal, fallback teks biasa:", e?.response?.data?.description || e?.message);
    }
  }
  try {
    return wrapOutgoing(await bot.telegram.sendMessage(chatId, text, { parse_mode, reply_markup }));
  } catch (e) {
    // Safety net: kalau Telegram menolak custom emoji, kirim ulang dengan emoji biasa
    // supaya pesan/menu TIDAK PERNAH gagal gara-gara emoji premium.
    if (!isEmojiError(e)) throw e;
    return wrapOutgoing(await bot.telegram.sendMessage(chatId, stripCustomEmoji(text), { parse_mode, reply_markup }));
  }
}

async function sendFile(chatId, opts = {}) {
  chatId = normalizeChatId(chatId);
  const parse_mode = mapParseMode(opts.parseMode);
  const reply_markup = opts.buttons ? { inline_keyboard: opts.buttons } : undefined;
  const { file, forwardRef } = normalizeFileArg(opts.file);
  return wrapOutgoing(
    await hybridFile.sendFileSmart(bot, chatId, {
      file,
      forwardRef,
      caption: opts.caption || "", // jalur GramJS: parser HTML-nya belum pasti paham <tg-emoji>, jadi tidak di-emojify
      parse_mode,
      reply_markup,
      forceDocument: opts.forceDocument,
      workers: opts.workers,
      progressCallback: opts.progressCallback,
      voiceNote: opts.voiceNote,
      attributes: opts.attributes,
    })
  );
}

// Khusus buat foto UI/dekoratif (welcome, notif user baru, dll — biasanya
// dari folder images/), SELALU lewat Telegraf, BUKAN GramJS. Alasannya:
// GramJS gak support field `style` (warna tombol Bot API 9.4), jadi kalau
// foto+tombol dikirim lewat GramJS, tombolnya jadi abu-abu polos. Foto UI
// ini selalu kecil & lokal, jadi aman & malah lebih cepat lewat Bot API.
async function sendPhotoTelegraf(chatId, opts = {}) {
  chatId = normalizeChatId(chatId);
  const { file, parseMode, buttons, forceDocument = false } = opts;
  const parse_mode = mapParseMode(parseMode);
  const caption = emojify(opts.caption || "", { parseMode: parse_mode });
  const reply_markup = buttons ? { inline_keyboard: buttons } : undefined;
  const sendIt = (cap) => {
    const src = { source: fs.createReadStream(file), filename: path.basename(file) };
    return forceDocument
      ? bot.telegram.sendDocument(chatId, src, { caption: cap, parse_mode, reply_markup })
      : bot.telegram.sendPhoto(chatId, src, { caption: cap, parse_mode, reply_markup });
  };
  let msg;
  try { msg = await sendIt(caption); }
  catch (e) { if (!isEmojiError(e)) throw e; msg = await sendIt(stripCustomEmoji(caption)); }
  return wrapOutgoing(msg);
}

async function editMessage(chatId, opts = {}) {
  chatId = normalizeChatId(chatId);
  const parse_mode = mapParseMode(opts.parseMode);
  const reply_markup = opts.buttons ? { inline_keyboard: opts.buttons } : undefined;
  let newText = emojify(opts.text, { parseMode: parse_mode });
  // Pesan ini dikirim sebagai Rich -> HARUS di-edit lewat editRichMessage
  if (RICH_MENUS && parse_mode === "HTML" && richui.isRich(chatId, opts.message)) {
    try {
      return await richui.editRich(chatId, opts.message, richui.htmlToRich(opts.text), reply_markup);
    } catch (e) {
      const d = String(e?.response?.data?.description || e?.message || "");
      if (/not modified/i.test(d)) return null;
      console.warn("[adapter] edit rich gagal:", d);
      throw e;
    }
  }
  try {
    try {
      return await bot.telegram.editMessageText(chatId, opts.message, undefined, newText, {
        parse_mode,
        reply_markup,
      });
    } catch (e0) {
      if (!isEmojiError(e0)) throw e0;
      newText = stripCustomEmoji(newText); // Telegram nolak custom emoji -> coba emoji biasa
      return await bot.telegram.editMessageText(chatId, opts.message, undefined, newText, {
        parse_mode,
        reply_markup,
      });
    }
  } catch (e) {
    // Pesan targetnya FOTO (ada caption, bukan teks biasa) -> editMessageText
    // gak bisa dipakai buat itu, Telegram butuh editMessageCaption. Ini
    // kejadian di banyak menu karena banyak pesan awalnya dikirim sebagai
    // foto (welcome photo dkk) lalu di-"edit" pas ganti menu.
    const msg = e?.message || e?.description || "";
    if (msg.includes("no text in the message to edit") || msg.includes("there is no text")) {
      return await bot.telegram.editMessageCaption(chatId, opts.message, undefined, newText, {
        parse_mode,
        reply_markup,
      });
    }
    throw e;
  }
}

async function deleteMessages(chatId, ids = []) {
  chatId = normalizeChatId(chatId);
  for (const id of ids) {
    try {
      await bot.telegram.deleteMessage(chatId, id);
    } catch (_) {}
  }
}

async function getEntity(idOrUsername) {
  const chat = await bot.telegram.getChat(normalizeChatId(idOrUsername));
  return {
    id: chat.id,
    firstName: chat.first_name || chat.title,
    username: chat.username,
    className: chat.type,
  };
}

async function getMe() {
  return await bot.telegram.getMe();
}

async function getMessages(chatId, { ids } = {}) {
  // Bot API TIDAK bisa ambil pesan lama by ID -> lewat MTProto (GramJS)
  const client = await mtproto.ensureConnected();
  const msgs = await client.getMessages(chatId, { ids });
  return msgs.map((m) => ({ message: m.message, caption: m.message }));
}

async function downloadMedia(msgLike, opts = {}) {
  const media = msgLike?.media || msgLike;
  const fileId = media?.fileId || media?.document?.fileId;
  const size = media?.size || media?.document?.size || 0;
  if (!fileId) throw new Error("[adapter] Pesan ini tidak punya file media untuk didownload");
  await hybridFile.downloadFileSmart(
    bot,
    { fileId, fileSize: size, chatId: msgLike.chatId, messageId: msgLike.id },
    opts.outputFile
  );
  return opts.outputFile;
}

async function downloadProfilePhoto(sender) {
  try {
    const userId = typeof sender === "object" ? sender.id : sender;
    const client = await mtproto.ensureConnected();
    const buf = await client.downloadProfilePhoto(userId, { isBig: false });
    return buf && buf.length ? buf : null;
  } catch (e) {
    console.warn("[adapter] downloadProfilePhoto gagal:", e.message);
    return null;
  }
}

async function setMyCommands(commands) {
  return await bot.telegram.setMyCommands(commands);
}

async function invoke() {
  throw new Error(
    "[adapter] client.invoke() tidak dipakai lagi di mode Telegraf — pakai client.setMyCommands() atau bot.telegram langsung."
  );
}

async function start() {
  // PENTING soal concurrency: Telegraf secara default memproses update
  // SATU-SATU berurutan — kalau handler di-`await` di sini, update
  // berikutnya (misal /start dari user lain) BARU diproses setelah yang
  // sekarang selesai total (cek 3 channel + load gambar + kirim pesan, dst).
  // Efeknya kalau lagi rame/di-spam, antreannya numpuk dan user ngerasa bot
  // "diem"/"stuck" padahal cuma lagi ngantre. GramJS versi lama gak seketat
  // ini soal urutan, makanya dulu kerasa lebih responsif pas rame.
  //
  // Fix: jangan di-`await` di sini — biar Telegraf langsung lanjut ambil
  // update berikutnya, dan tiap /start atau callback diproses PARALEL
  // (bukan antre satu-satu). Error tetap ketangkep lewat .catch().
  // ─── Bridge ke modul TOOLS/GAME/RPG/GROUP (legacyBridge) ────────────────────
  // Update yang jelas milik modul tools diteruskan ke sana dan TIDAK lanjut ke
  // handler AAAAA (supaya tidak dobel-balas / kesangkut state flow build).
  // Callback & command milik AAAAA (build, rename, domain, dll) lewat seperti biasa.
  let legacyFeed = null;
  try {
    legacyFeed = require("./legacyBridge").feed;
  } catch (e) {
    console.error("[adapter] legacyBridge gagal dimuat, fitur tools nonaktif:", e.message);
  }
  bot.use(async (ctx, next) => {
    if (legacyFeed) {
      try {
        if (legacyFeed(ctx.update)) return;
      } catch (e) {
        console.error("[adapter] legacyFeed error:", e.message);
      }
    }
    return next();
  });

  bot.use(async (ctx, next) => {
    for (const hook of rawHooks) {
      try {
        if (await hook(ctx)) return; // sudah ditangani modul
      } catch (e) {
        console.error("[adapter] raw hook error:", e?.message || e);
      }
    }
    return next();
  });

  bot.on("message", async (ctx) => {
    const joinedMembers = ctx.message?.new_chat_members;
    if (Array.isArray(joinedMembers) && joinedMembers.length && ctx.chat?.type !== "private") {
      try {
        const richui = require("./richui");
        const me = ctx.botInfo || await ctx.telegram.getMe();
        const botUrl = `https://t.me/${me.username}`;
        const groupUrl = `${botUrl}?startgroup=true`;
        let count = null;
        try { count = await ctx.telegram.getChatMembersCount(ctx.chat.id); } catch (_) {}
        for (const member of joinedMembers) {
          // Не приветствовать самого бота как нового участника.
          if (member.id === me.id) continue;
          const name = [member.first_name, member.last_name].filter(Boolean).join(" ") || "Teman baru";
          const { html, markup } = richui.buildGroupJoinWelcome({
            memberName: name, username: member.username || "", chatTitle: ctx.chat.title || "Grup",
            memberCount: count, botUrl, groupUrl,
          });
          await richui.sendRichSafe(ctx.chat.id, html, markup);
        }
      } catch (e) {
        console.error("[WELCOME GROUP] Gagal mengirim Rich welcome:", e?.message || e);
        try {
          const names = joinedMembers.filter(m => m.id !== ctx.botInfo?.id)
            .map(m => [m.first_name, m.last_name].filter(Boolean).join(" ") || "Teman baru");
          if (names.length) await ctx.reply(`✨ <b>Selamat datang!</b>\n\n${names.map(n => `👋 ${String(n).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")}`).join("\n")}\n\nSemoga betah di <b>${String(ctx.chat.title || "grup ini").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")}</b>!`, { parse_mode: "HTML" });
        } catch (_) {}
      }
      return; // Jangan teruskan service message join ke handler command lama.
    }
    console.log(`📨 [adapter] Update pesan masuk dari ${ctx.from?.id} (${ctx.from?.username || "-"}): "${ctx.message?.text || "[non-text]"}"`);
    if (!messageHandler) {
      console.warn("⚠️ [adapter] messageHandler belum terdaftar, update ini dilewati.");
      return;
    }
    const chatId = ctx.chat.id;
    const msg = wrapMessage(ctx.message, chatId, ctx.chat.type);
    messageHandler({ message: msg, chatId }).catch((e) =>
      console.error("[adapter] message handler error:", e)
    );
  });

  bot.on("callback_query", (ctx) => {
    console.log(`🔘 [adapter] Callback masuk dari ${ctx.callbackQuery.from?.id}: "${ctx.callbackQuery.data}"`);
    if (!callbackHandler) {
      console.warn("⚠️ [adapter] callbackHandler belum terdaftar, update ini dilewati.");
      return;
    }
    const cq = ctx.callbackQuery;
    const chatId = cq.message?.chat.id;
    callbackHandler({
      data: Buffer.from(cq.data || ""),
      chatId,
      isPrivate: cq.message?.chat?.type === "private",
      senderId: cq.from.id,
      messageId: cq.message?.message_id,
      answer: async (a = {}) => {
        try {
          await ctx.answerCbQuery(a.message || undefined, { show_alert: !!a.alert });
        } catch (_) {}
      },
    }).catch((e) => {
      console.error("[adapter] callback handler error:", e);
    });
  });

  bot.catch((err) => console.error("[adapter] Telegraf error:", err));

  // Hapus webhook lama kalau ada — kalau webhook masih aktif, long-polling
  // TIDAK akan pernah menerima update apapun (Telegram cuma kirim ke satu-satunya
  // jalur yang aktif: webhook ATAU polling, gak bisa dua-duanya).
  try {
    const info = await bot.telegram.getWebhookInfo();
    if (info.url) {
      console.log(`🧹 [adapter] Webhook lama terdeteksi (${info.url}) -> dihapus supaya polling bisa jalan...`);
      await bot.telegram.deleteWebhook({ drop_pending_updates: false });
    }
  } catch (e) {
    console.error("[adapter] gagal cek/hapus webhook:", e.message);
  }

  if (GLOBAL_CHAT_URL && /^https:\/\//i.test(GLOBAL_CHAT_URL)) {
    try {
      await bot.telegram.setChatMenuButton({
        menu_button: { type: "web_app", text: "Global Chat", web_app: { url: GLOBAL_CHAT_URL } },
      });
      console.log("[global-chat] Menu button Mini App aktif.");
    } catch (e) {
      console.warn("[global-chat] Gagal mengatur menu button:", e.message);
    }
  }

  // PENTING: bot.launch() di Telegraf BLOCKING — promise-nya baru resolve
  // kalau bot di-stop, BUKAN pas polling berhasil nyala. Kalau di-`await`,
  // baris `client.addEventHandler(...)` di index.js (yang dipanggil setelah
  // `await client.start()`) gak akan PERNAH kejalan, jadi messageHandler /
  // callbackHandler selamanya null -> bot connect tapi gak pernah nyaut apa-apa.
  // Makanya di sini SENGAJA gak di-await.
  bot.launch()
    .then(() => console.log("✅ [adapter] Polling Telegraf aktif."))
    .catch((e) => console.error("❌ [adapter] bot.launch() gagal:", e));

  process.once("SIGINT", () => bot.stop("SIGINT"));
  process.once("SIGTERM", () => bot.stop("SIGTERM"));
}

const client = {
  registerRawHook,
  sendMessage,
  sendFile,
  sendPhotoTelegraf,
  editMessage,
  deleteMessages,
  getEntity,
  getMe,
  getMessages,
  downloadMedia,
  downloadProfilePhoto,
  setMyCommands,
  invoke,
  addEventHandler,
  start,
};

module.exports = { bot, client, NewMessage, CallbackQuery };
