'use strict';
const crypto = require('crypto');
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { MongoClient } = require('mongodb');

const required = ['BOT_TOKEN', 'MONGODB_URI'];
for (const key of required) if (!process.env[key]) throw new Error(`Environment variable ${key} wajib diisi`);
const PORT = Number(process.env.PORT || 3000);
const MAX_AGE = Number(process.env.TELEGRAM_AUTH_MAX_AGE || 86400);
const OWNER_USERNAMES = new Set((process.env.OWNER_USERNAMES || 'yonzgntg,xenodanz').split(',').map(x => x.trim().replace(/^@/, '').toLowerCase()).filter(Boolean));
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: false }, maxHttpBufferSize: 16_000 });
app.disable('x-powered-by');
app.use(express.static(require('path').join(__dirname, 'public'), { index: false, maxAge: '1h' }));
app.get('/health', (_req, res) => res.json({ ok: true, service: 'yonz-global-chat' }));
app.get('/', (_req, res) => res.sendFile(require('path').join(__dirname, 'public', 'index.html')));

function verifyInitData(initData) {
  if (typeof initData !== 'string' || !initData || initData.length > 8192) throw new Error('Data autentikasi tidak valid');
  const params = new URLSearchParams(initData);
  const hash = params.get('hash');
  if (!hash || !/^[a-f0-9]{64}$/i.test(hash)) throw new Error('Hash Telegram tidak ditemukan');
  params.delete('hash');
  const authDate = Number(params.get('auth_date'));
  if (!Number.isFinite(authDate) || Math.floor(Date.now() / 1000) - authDate > MAX_AGE || authDate > Math.floor(Date.now() / 1000) + 30) throw new Error('Sesi Telegram kedaluwarsa. Buka ulang Mini App.');
  const dataCheckString = [...params.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => `${k}=${v}`).join('\n');
  const secret = crypto.createHmac('sha256', process.env.BOT_TOKEN).update('WebAppData').digest();
  const calculated = crypto.createHmac('sha256', secret).update(dataCheckString).digest('hex');
  const a = Buffer.from(calculated, 'hex');
  const b = Buffer.from(hash, 'hex');
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) throw new Error('Verifikasi Telegram gagal');
  const userRaw = params.get('user');
  if (!userRaw) throw new Error('Data user Telegram tidak ditemukan');
  const user = JSON.parse(userRaw);
  if (!Number.isSafeInteger(user.id)) throw new Error('ID Telegram tidak valid');
  const username = String(user.username || '').replace(/^@/, '').slice(0, 64);
  const name = [user.first_name, user.last_name].filter(Boolean).join(' ').slice(0, 100) || 'Telegram User';
  const photo = typeof user.photo_url === 'string' && /^https:\/\//i.test(user.photo_url) ? user.photo_url : '';
  return { id: user.id, username, name, photo, verifiedOwner: OWNER_USERNAMES.has(username.toLowerCase()) };
}

let messages;
const socketsByUser = new Map();
const rate = new Map();
function allowedToSend(id) {
  const now = Date.now(); const prev = rate.get(id) || [];
  const recent = prev.filter(t => now - t < 10000);
  if (recent.length >= 5) { rate.set(id, recent); return false; }
  recent.push(now); rate.set(id, recent); return true;
}
function publicMessage(doc) {
  return { id: String(doc._id), text: doc.text, date: doc.date.toISOString(), user: doc.user };
}
io.use((socket, next) => {
  try { socket.user = verifyInitData(socket.handshake.auth?.initData); next(); }
  catch (e) { next(new Error(e.message || 'Autentikasi ditolak')); }
});
io.on('connection', async socket => {
  const user = socket.user;
  socketsByUser.set(user.id, (socketsByUser.get(user.id) || 0) + 1);
  socket.emit('session', { user });
  try {
    const recent = await messages.find({}).sort({ date: -1 }).limit(60).toArray();
    socket.emit('history', recent.reverse().map(publicMessage));
  } catch (e) { socket.emit('app-error', 'Gagal memuat riwayat chat.'); }
  socket.on('send-message', async payload => {
    try {
      if (!allowedToSend(user.id)) return socket.emit('app-error', 'Terlalu cepat. Tunggu beberapa detik.');
      const text = String(payload?.text || '').trim();
      if (!text || text.length > 2000) return socket.emit('app-error', 'Pesan harus 1–2000 karakter.');
      const doc = { text, date: new Date(), user: { id: user.id, username: user.username, name: user.name, photo: user.photo, verifiedOwner: user.verifiedOwner } };
      const result = await messages.insertOne(doc);
      doc._id = result.insertedId;
      io.emit('new-message', publicMessage(doc));
    } catch (e) { socket.emit('app-error', 'Pesan gagal dikirim. Coba lagi.'); }
  });
  socket.on('disconnect', () => {
    const count = (socketsByUser.get(user.id) || 1) - 1;
    if (count > 0) socketsByUser.set(user.id, count); else socketsByUser.delete(user.id);
  });
});

(async () => {
  const mongo = new MongoClient(process.env.MONGODB_URI);
  await mongo.connect();
  const db = mongo.db(process.env.MONGODB_DB || 'yonz_global_chat');
  messages = db.collection('messages');
  await messages.createIndex({ date: -1 });
  await messages.createIndex({ 'user.id': 1, date: -1 });
  server.listen(PORT, '0.0.0.0', () => console.log(`YONZ Global Chat listening on ${PORT}`));
})().catch(err => { console.error('Startup failed:', err); process.exit(1); });
