# YONZ Global Chat — Render deployment

## Render Web Service
- Root Directory: `global-chat`
- Runtime: Node
- Build Command: `npm install`
- Start Command: `npm start`
- Instance: Free

Environment variables:
- `BOT_TOKEN`: token bot Telegram (secret; jangan commit)
- `MONGODB_URI`: MongoDB Atlas connection string
- `MONGODB_DB`: `yonz_global_chat` (optional)
- `OWNER_USERNAMES`: `yonzgntg,xenodanz`
- `TELEGRAM_AUTH_MAX_AGE`: `86400` (optional)

Setelah deploy, salin URL HTTPS Render. Di service bot set `GLOBAL_CHAT_URL` ke URL tersebut.

## Telegram
Bot menyediakan command `/globalchat` yang mengirim tombol Mini App. Tambahkan URL yang sama sebagai Web App URL di BotFather bila ingin memakai menu button. Jangan pernah mempercayai user ID/username dari browser; server memvalidasi `Telegram.WebApp.initData` dengan BOT_TOKEN.

## Database
Buat cluster MongoDB Atlas, buat database user dengan password kuat, dan allowlist koneksi sesuai instruksi Atlas. Render Free filesystem tidak persisten, jadi pesan disimpan di MongoDB.
