(() => {
  const tg = window.Telegram?.WebApp;
  const gate = document.getElementById('gate'), gateText = document.getElementById('gateText');
  const app = document.getElementById('app'), list = document.getElementById('messages');
  const input = document.getElementById('messageInput'), form = document.getElementById('composer');
  const toast = document.getElementById('toast'); let socket;
  function showError(msg) { toast.textContent = msg; toast.style.display = 'block'; clearTimeout(showError.timer); showError.timer = setTimeout(() => toast.style.display = 'none', 3500); }
  if (!tg || !tg.initData) { gateText.textContent = 'Akses ditolak. Masuk melalui tombol Mini App di bot Telegram untuk memverifikasi akun.'; const link = document.getElementById('openBot'); link.href = 'https://t.me/' + (document.documentElement.dataset.bot || ''); link.hidden = false; return; }
  tg.ready(); tg.expand();
  socket = io({ auth: { initData: tg.initData }, transports: ['websocket', 'polling'] });
  socket.on('connect', () => { gate.hidden = true; app.hidden = false; input.focus(); });
  socket.on('connect_error', err => { gate.hidden = false; gateText.textContent = err.message || 'Verifikasi gagal. Tutup dan buka ulang Mini App.'; });
  socket.on('app-error', showError);
  socket.on('history', items => { list.replaceChildren(); items.forEach(addMessage); scrollBottom(); });
  socket.on('new-message', msg => { addMessage(msg); scrollBottom(); });
  function addMessage(msg) {
    const mine = String(msg.user.id) === String(tg.initDataUnsafe?.user?.id);
    const wrap = document.createElement('article'); wrap.className = 'message' + (mine ? ' mine' : '');
    const identity = document.createElement('div'); identity.className = 'identity';
    const avatar = msg.user.photo ? document.createElement('img') : document.createElement('span');
    avatar.className = 'avatar'; if (msg.user.photo) { avatar.src = msg.user.photo; avatar.alt = ''; } else { avatar.classList.add('fallback'); avatar.textContent = (msg.user.name || '?').slice(0,1).toUpperCase(); }
    const details = document.createElement('span');
    const name = document.createElement('b'); name.textContent = msg.user.name || 'Telegram User'; details.append(name);
    if (msg.user.username) { const username = document.createElement('span'); username.className = 'username'; username.textContent = ' @' + msg.user.username; details.append(username); }
    if (msg.user.verifiedOwner) { const badge = document.createElement('span'); badge.className = 'verified'; badge.textContent = ' ✓'; badge.title = 'Verified owner'; details.append(badge); }
    identity.append(avatar, details);
    const bubble = document.createElement('div'); bubble.className = 'bubble'; bubble.textContent = msg.text;
    const time = document.createElement('div'); time.className = 'time'; time.textContent = new Date(msg.date).toLocaleTimeString('id-ID', {hour:'2-digit',minute:'2-digit'});
    wrap.append(identity, bubble, time); list.append(wrap);
  }
  function scrollBottom() { list.scrollTop = list.scrollHeight; }
  form.addEventListener('submit', e => { e.preventDefault(); const text = input.value.trim(); if (!text || !socket?.connected) return; socket.emit('send-message', { text }); input.value = ''; });
})();
