# Integrasi YONZ Global Chat

## Isi patch
- `global-chat/`: aplikasi Telegram Mini App + realtime chat.
- `telegramAdapter.js`: command `/globalchat` dan tombol menu Mini App.

## Pasang ke source bot
1. Salin folder `global-chat/` ke root repository bot.
2. Ganti `telegramAdapter.js` dengan versi dari patch ini.
3. Commit dan push ke GitHub (jangan pernah commit `.env`, session, token, atau file worker berisi credential).

## Deploy Render
Buat Web Service baru dari repository yang sama:
- Root Directory: `global-chat`
- Build Command: `npm install`
- Start Command: `npm start`
- Plan: Free

Tambahkan Environment Variables pada Render:
- `BOT_TOKEN` = token bot Telegram yang sama dengan bot
- `MONGODB_URI` = URI MongoDB Atlas
- `MONGODB_DB` = `yonz_global_chat`
- `OWNER_USERNAMES` = `yonzgntg,xenodanz`

Setelah deploy, salin URL HTTPS Render. Pada environment bot yang menjalankan `index.js`, tambahkan:
- `GLOBAL_CHAT_URL` = URL HTTPS Render tersebut

Restart bot. User dapat mengirim `/globalchat` atau menekan tombol menu `Global Chat`.

## Catatan
- Direct browser access ditolak; Telegram `initData` diverifikasi di backend memakai BOT_TOKEN.
- Chat disimpan di MongoDB, bukan disk Render.
- Owner badge saat ini memakai username yang tervalidasi dari Telegram. Untuk identitas owner yang tahan terhadap perubahan username, tambahkan Telegram numeric user ID owner ke allowlist setelah ID kedua dikonfirmasi.
- `global-chat` memerlukan Node.js 20+.
